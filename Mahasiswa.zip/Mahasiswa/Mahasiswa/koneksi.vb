﻿Imports MySql.Data.MySqlClient
Module ModuleKoneksiMySQL
    Public conn As MySqlConnection
    Public cmd As MySqlCommand
    Public rd As MySqlDataReader
    Public da As MySqlDataAdapter
    Public ds As DataSet
    Public dt As DataTable
    Public str As String
    Sub koneksi()
        Try
            Dim str As String = "Server=localhost;user id=root;password=;database=perkuliahandb"
            conn = New MySqlConnection(str)
            If conn.State = ConnectionState.Closed Then
                conn.Open()
            End If
        Catch ex As Exception
            MessageBox.Show("Konkeksi Gagal" & vbCrLf & "Mohon Cek APakah Server SUdah Siap...!!!", "Koneksi Ke Server", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub
End Module
