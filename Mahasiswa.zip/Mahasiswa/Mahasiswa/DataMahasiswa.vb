﻿'       DONT DELETE THIS        '
'      CREATED BY FAREZ.SYX     '
'     FOLLOW ME IG:FAREZ.SYX    '
Imports Mahasiswa.koneksi
Imports MySql.Data.MySqlClient
Public Class DataMahasiswa
    Private Sub bersih()
        txtnim.Text = ""
        txtnama.Text = ""
        txtalamat.Text = ""
        txttempat.Text = ""
        cbxjekel.SelectedIndex = -1
        tanggal.Text = ""
    End Sub
    Dim perintah As New MySqlCommand
    Dim data As New MySqlDataAdapter
    Dim ds As New DataSet
    Private Sub tampildata()
        Call koneksi()
        Dim dt As DataTable
        Dim sqlstr As String
        Dim data As Integer

        sqlstr = "Select * from mahasiswa"
        da = New MySqlDataAdapter(sqlstr, conn)
        dt = New DataTable
        data = da.Fill(dt)

        If data > 0 Then
            'nama header pada datagrid
            tabelmhs.DataSource = dt
            tabelmhs.AutoSizeColumnsMode = DataGridViewAutoSizeColumnMode.Fill
            tabelmhs.Columns(0).HeaderText = "NIM"
            tabelmhs.Columns(1).HeaderText = "NAMA"
            tabelmhs.Columns(2).HeaderText = "JENIS KELAMIN"
            tabelmhs.Columns(3).HeaderText = "TEMPAT"
            tabelmhs.Columns(4).HeaderText = "TGL. LAHIR"
            tabelmhs.Columns(5).HeaderText = "ALAMAT"
        Else
            tabelmhs.DataSource = Nothing
        End If
        bersih()
        'tutup()
    End Sub

    Private Sub btnsimpan_Click(sender As Object, e As EventArgs) Handles btnsimpan.Click
        Try
            Dim str As String
            str = "insert into mahasiswa values ('" & txtnim.Text & "','" & txtnama.Text & "', '" & cbxjekel.Text & "', '" & txttempat.Text & "', '" & tanggal.Text & "', '" & txtalamat.Text & "')"
            cmd = New MySqlCommand(str, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Disimpan", MsgBoxStyle.Information, "Informasi")
            Call tampildata()
        Catch ex As Exception
            MsgBox("Data Gagal Disimpan", +ex.Message, MsgBoxStyle.Critical)
        End Try
    End Sub

    Private Sub DataMahasiswa_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call tampildata()
        tanggal.Format = DateTimePickerFormat.Custom
        tanggal.CustomFormat = "yyyy/MM/dd"
    End Sub

    Private Sub tabelmhs_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles tabelmhs.CellContentClick
        Dim i As Integer
        i = Me.tabelmhs.CurrentCell.RowIndex
        With tabelmhs.Rows.Item(i)
            Me.txtnim.Text = .Cells(0).Value
            Me.txtnama.Text = .Cells(1).Value
            Me.cbxjekel.Text = .Cells(2).Value
            Me.txttempat.Text = .Cells(3).Value
            Me.tanggal.Text = .Cells(4).Value
            Me.txtalamat.Text = .Cells(5).Value
        End With
        txtnim.Enabled = False
        btnsimpan.Enabled = False
    End Sub

    Private Sub btnedit_Click(sender As Object, e As EventArgs) Handles btnedit.Click
        Try
            Call koneksi()
            Dim str As String
            str = "Update mahasiswa set NAMA = '" & txtnama.Text & "', JEKEL = '" & cbxjekel.Text & "', TEMPAT = '" & txttempat.Text & "', TGL = '" & tanggal.Text & "', ALAMAT = '" & txtalamat.Text & "' where NIM = '" & txtnim.Text & "'"
            cmd = New MySqlCommand(str, conn)
            cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Diubah", MsgBoxStyle.Information, "Informasi")
            Call tampildata()
        Catch ex As Exception
            MsgBox("Data Gagal Diubah", +ex.Message, MsgBoxStyle.Critical)
        End Try
        tampildata()
        btnsimpan.Enabled = True
        txtnim.Enabled = True
        txtnim.Focus()
    End Sub

    Private Sub btnhapus_Click(sender As Object, e As EventArgs) Handles btnhapus.Click
        Dim hasil As MsgBoxResult = MessageBox.Show("Apakah Data ingin Dihapus?", "Pesan",
                                                    MessageBoxButtons.OKCancel, MessageBoxIcon.Warning)
        If hasil = vbOK Then
            Try
                Call koneksi()
                Dim str As String
                str = "delete from mahasiswa where NIM = '" & txtnim.Text & "'"
                cmd = New MySqlCommand(str, conn)
                cmd.ExecuteNonQuery()
                MsgBox("Data Berhasil Dihapus", MsgBoxStyle.Information, "Informasi")
            Catch ex As Exception
                MsgBox("Data Gagal Dihapus", +ex.Message, MsgBoxStyle.Critical)
            End Try
        End If
        tampildata()
        btnsimpan.Enabled = True
        txtnim.Enabled = True
        txtnim.Focus()
    End Sub

    Private Sub btnkeluar_Click(sender As Object, e As EventArgs) Handles btnkeluar.Click
        Me.Close()
    End Sub

    Private Sub txtcari_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtcari.KeyPress
        Call koneksi()
        Dim dt As DataTable
        Dim sqlstr As String
        Dim data As Integer
        If cbxcari.Text = "Nim" Then
            sqlstr = "Select * from mahasiswa where nim like '%" & txtcari.Text & "%'"
        Else cbxcari.Text = "Nama"
            sqlstr = "Select * from mahasiswa where nama like '%" & txtcari.Text & "%'"
        End If
        da = New MySqlDataAdapter(sqlstr, conn)
        dt = New DataTable
        data = da.Fill(dt)

        If data > 0 Then
            'nama header pada datagrid
            tabelmhs.DataSource = dt
            tabelmhs.AutoSizeColumnsMode = DataGridViewAutoSizeColumnMode.Fill
            tabelmhs.Columns(0).HeaderText = "NIM"
            tabelmhs.Columns(1).HeaderText = "NAMA"
            tabelmhs.Columns(2).HeaderText = "JENIS KELAMIN"
            tabelmhs.Columns(3).HeaderText = "TEMPAT"
            tabelmhs.Columns(4).HeaderText = "TGL. LAHIR"
            tabelmhs.Columns(5).HeaderText = "ALAMAT"
        Else
            tabelmhs.DataSource = Nothing
            MsgBox("Data Tidak Ditemukan", MsgBoxStyle.Information, "Informasi")
        End If
    End Sub
End Class
